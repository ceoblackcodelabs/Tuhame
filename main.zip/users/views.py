# apps/dashboard/views.py
from django.views.generic import FormView, TemplateView, DetailView, UpdateView, View, CreateView, ListView
from .models import Profile
from django.http import JsonResponse, Http404
import base64
from django.core.files.base import ContentFile
from django.conf import settings
import uuid

from django.urls import reverse
from django.db.models import Avg, Count
from home.models import ViewingSchedule, SavedProperty
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.urls import reverse_lazy
from django.contrib import messages
from django.shortcuts import redirect, get_object_or_404, render
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import RedirectView
from .forms import ProfileForm, UserRegistrationForm
from django.db import models
import qrcode
from io import BytesIO
import base64
from .utils import generate_qr_code_for_user

from django.contrib.auth import get_user_model
User = get_user_model()

class LoginView(FormView):
    """
    Custom Login View using Class-Based View
    """
    template_name = 'auth/login.html'
    form_class = AuthenticationForm

    def get_success_url(self, user=None):
        """
        Respects a 'next' redirect target (e.g. from a login-required page),
        otherwise sends verified property owners to their dashboard and
        everyone else to the home page.
        """
        next_url = self.request.GET.get('next') or self.request.POST.get('next')
        if next_url and next_url.startswith('/'):
            return next_url
        if user and hasattr(user, 'profile') and user.profile.role == 'owner' and user.profile.is_verified_owner:
            return reverse_lazy('home:home')
        return reverse_lazy('home:home')

    def dispatch(self, request, *args, **kwargs):
        """Redirect already-authenticated users straight through"""
        if request.user.is_authenticated:
            return redirect(self.get_success_url(request.user))
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        """Process valid form and log in user"""
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(self.request, username=username, password=password)

        if user is not None:
            login(self.request, user)
            messages.success(self.request, f'Welcome back, {user.get_full_name() or user.username}!')
            return redirect(self.get_success_url(user))
        else:
            messages.error(self.request, 'Invalid username or password.')
            return self.form_invalid(form)

    def form_invalid(self, form):
        """Handle invalid form submission"""
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)

    def get_context_data(self, **kwargs):
        """Add extra context to template"""
        context = super().get_context_data(**kwargs)
        context['title'] = 'Login - Real Estate Management System'
        return context

class RegisterView(CreateView):
    """
    User Registration View
    """
    template_name = 'auth/register.html'
    form_class = UserRegistrationForm
    success_url = reverse_lazy('home:home')

    def dispatch(self, request, *args, **kwargs):
        """Redirect authenticated users to dashboard"""
        if request.user.is_authenticated:
            return redirect('dashboard')
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        """Save user and log them in"""
        response = super().form_valid(form)

        # Log the user in after registration
        user = self.object
        login(self.request, user)

        messages.success(
            self.request,
            f'Welcome to 2Hame, {user.get_full_name() or user.username}! 🎉 Your account has been created successfully.'
        )

        return response

    def form_invalid(self, form):
        """Handle invalid form submission"""
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)

    def get_context_data(self, **kwargs):
        """Add extra context to template"""
        context = super().get_context_data(**kwargs)
        context['title'] = 'Create Account - 2Hame'
        return context

class LogoutView(RedirectView):
    """
    Custom Logout View using Class-Based View
    """
    url = reverse_lazy('login')

    def get(self, request, *args, **kwargs):
        """Log out the user and redirect to login page"""
        logout(request)
        messages.success(request, 'You have been successfully logged out.')
        return super().get(request, *args, **kwargs)


class DashboardView(LoginRequiredMixin, TemplateView):
    """
    Dashboard View - Only accessible after login
    """
    template_name = 'dashboard.html'
    login_url = reverse_lazy('login')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add dashboard statistics here
        return context

# public profile view by username
class PublicProfileView(DetailView):
    """Public profile view by username - NO LOGIN REQUIRED"""
    model = Profile
    template_name = 'auth/public_profile.html'
    context_object_name = 'profile'
    slug_field = 'user__username'
    slug_url_kwarg = 'username'

    def get_queryset(self):
        return Profile.objects.filter(is_active=True, user__is_active=True)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.get_object()
        user = profile.user

        # Only show public information
        context['full_name'] = profile.get_full_name()
        context['user'] = user
        context['phone'] = profile.phone_number
        context['email'] = user.email
        context['current_property'] = profile.current_property
        context['city'] = profile.city
        context['country'] = profile.country
        context['profile_picture'] = profile.profile_picture
        context['is_public'] = True
        return context

#token qr
class PublicProfileByTokenView(DetailView):
    """Public profile view - NO LOGIN REQUIRED"""
    model = Profile
    template_name = 'auth/public_profile.html'
    context_object_name = 'profile'
    slug_field = 'qr_code_token'
    slug_url_kwarg = 'token'

    def get_queryset(self):
        return Profile.objects.filter(is_active=True)

    def get_object(self, queryset=None):
        try:
            return super().get_object(queryset)
        except (ValueError, TypeError, Profile.DoesNotExist):
            raise Http404("Profile not found")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.get_object()
        user = profile.user

        # All public information including emergency contact
        context['full_name'] = profile.get_full_name()
        context['user'] = user
        context['phone'] = profile.phone_number
        context['email'] = user.email
        context['current_property'] = profile.current_property
        context['city'] = profile.city
        context['country'] = profile.country
        context['profile_picture'] = profile.profile_picture
        context['bio'] = profile.bio
        context['occupation'] = profile.occupation
        context['employer'] = profile.employer
        context['total_moves'] = profile.move_history.count()
        context['is_public'] = True

        # Emergency contact information
        context['emergency_contact_name'] = profile.emergency_contact_name
        context['emergency_contact_phone'] = profile.emergency_contact_phone
        context['emergency_contact_relationship'] = profile.emergency_contact_relationship

        # Generate QR code for this profile
        from .utils import generate_qr_code_for_user
        context['qr_code'] = generate_qr_code_for_user(profile)

        # Public URL for sharing
        base_url = settings.SITE_URL.rstrip('/')
        context['public_url'] = f"{base_url}/users/qr/{profile.qr_code_token}/"

        return context

# LOGGED IN USER PROFILE VIEW
from home.models import MoveRequest, MoveChecklistItem
from properties.models import Property
class MyProfileView(LoginRequiredMixin, DetailView):
    """View for users to see their own profile"""

    model = Profile
    template_name = "auth/my_profile.html"
    context_object_name = "profile"

    def get_object(self, queryset=None):
        """Get the profile of the currently logged-in user (creating it if missing)"""
        profile, _ = Profile.objects.get_or_create(user=self.request.user)
        return profile

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

         # Move requests
        context['move_requests'] = MoveRequest.objects.filter(
            user=self.request.user
        ).order_by('-created_at')[:10]

        # Available properties for move to
        context['available_properties'] = Property.objects.filter(
            is_active=True,
            status='available'
        )

        # Checklist progress - backed by MoveChecklistItem, seeded with sensible
        # defaults the first time a user visits (previously this was hardcoded
        # to 7/12/58% for everyone and never matched the on-page checklist)
        checklist_items = MoveChecklistItem.objects.filter(user=self.request.user)
        if not checklist_items.exists():
            checklist_items = MoveChecklistItem.seed_defaults_for(self.request.user)

        checklist_total = checklist_items.count()
        checklist_progress = checklist_items.filter(done=True).count()
        checklist_percentage = round((checklist_progress / checklist_total) * 100) if checklist_total else 0

        context['checklist_items'] = checklist_items
        context['checklist_items_json'] = [
            {'id': item.pk, 'text': item.text, 'done': item.done} for item in checklist_items
        ]
        context['checklist_progress'] = checklist_progress
        context['checklist_total'] = checklist_total
        context['checklist_percentage'] = checklist_percentage

        context['user'] = self.request.user

        # Get move history for this user
        context['move_history'] = self.request.user.move_history.all()[:5]

        # Get upcoming viewings
        context['upcoming_viewings'] = ViewingSchedule.objects.filter(
            user=self.request.user,
            status__in=['pending', 'confirmed']
        ).order_by('preferred_date')[:5]

        # Get bills for user's current property
        profile, _ = Profile.objects.get_or_create(user=self.request.user)
        if profile.current_property:
            # Get all bills for the current property
            context['bills'] = profile.current_property.bills.filter(
                is_active=True
            ).order_by('-due_date', '-created_at')

            # Get bill statistics
            bills = context['bills']
            context['total_bills'] = bills.count()
            context['paid_bills'] = bills.filter(status='paid').count()
            context['pending_bills'] = bills.filter(status='pending').count()
            context['overdue_bills'] = bills.filter(status='overdue').count()
            context['total_amount_due'] = bills.filter(
                status__in=['pending', 'overdue']
            ).aggregate(total=models.Sum('amount'))['total'] or 0

            # Get utility usage for current property
            context['utility_usage'] = profile.current_property.utility_usage.all().order_by('-reading_date')[:3]
        else:
            context['bills'] = []
            context['total_bills'] = 0
            context['paid_bills'] = 0
            context['pending_bills'] = 0
            context['overdue_bills'] = 0
            context['total_amount_due'] = 0
            context['utility_usage'] = []

        # Get saved properties
        saved_properties = SavedProperty.objects.filter(
            user=self.request.user
        ).select_related('property').annotate(
            avg_rating=Avg('property__reviews__rating'),
            review_count=Count('property__reviews', distinct=True),
        ).order_by('-saved_at')

        context['saved_properties'] = saved_properties
        context['saved_properties_count'] = saved_properties.count()

        # Generate QR Code
        context['qr_code_data'] = generate_qr_code_for_user(profile)
        # print(context['qr_code_data'])

        return context

class MyProfileUpdateView(LoginRequiredMixin, UpdateView):
    """View for users to update their own profile"""

    model = Profile
    form_class = ProfileForm
    template_name = "auth/edit_profile.html"

    def get_object(self, queryset=None):
        """Get the profile of the currently logged-in user (creating it if missing)"""
        profile, _ = Profile.objects.get_or_create(user=self.request.user)
        return profile

    def get_success_url(self):
        return reverse_lazy('my_profile')

    def form_valid(self, form):
        """Handle successful form submission"""
        previous_role = Profile.objects.get(pk=form.instance.pk).role
        response = super().form_valid(form)

        # If they just switched to (or re-affirmed) an elevated role and aren't
        # verified yet, kick off the admin verification workflow
        if form.instance.role in ('owner', 'mover') and not form.instance.is_verified_for_role():
            if previous_role != form.instance.role or form.instance.verification_status == 'none':
                form.instance.request_role_verification()
                role_label = 'property owner' if form.instance.role == 'owner' else 'mover'
                messages.info(
                    self.request,
                    f"Your request to become a verified {role_label} has been submitted. "
                    "Our team will review it shortly."
                )

        messages.success(self.request, "Your profile has been updated successfully!")
        return response

    def form_invalid(self, form):
        """Handle invalid form submission"""
        messages.error(self.request, "Please correct the errors below.")
        return super().form_invalid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['user'] = self.request.user
        return context


class ProfileDetailView(LoginRequiredMixin, DetailView):
    """View for admins/landlords to see another user's profile"""

    model = Profile
    template_name = "auth/profile_detail.html"
    context_object_name = "profile"
    slug_field = 'user__username'
    slug_url_kwarg = 'username'

    def get_queryset(self):
        """Only allow viewing profiles if user is admin or landlord"""
        queryset = super().get_queryset()

        # If user is staff or superuser, allow viewing all
        if self.request.user.is_staff or self.request.user.is_superuser:
            return queryset

        # If user is a property owner, allow viewing profiles of tenants in their properties
        # Get all properties owned by this user
        owned_properties = self.request.user.owned_properties.values_list('id', flat=True)

        # Only show profiles of residents in those properties
        return queryset.filter(current_property__in=owned_properties)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Check if the current user can edit this profile
        context['can_edit'] = (
            self.request.user.is_staff or
            self.request.user.is_superuser or
            self.request.user == self.object.user
        )

        return context

class OwnerQRCardView(LoginRequiredMixin, View):
    """QR business card for a verified property owner, linking to their public portfolio"""

    def get(self, request):
        profile = request.user.profile
        if profile.role != 'owner' or not profile.is_verified_owner:
            messages.error(request, "You need to be a verified property owner to get an Owner QR card.")
            return redirect('my_profile')

        from django.conf import settings
        from django.urls import reverse
        from users.utils import generate_qr_code_for_url

        portfolio_url = settings.SITE_URL.rstrip('/') + reverse('home:owner_portfolio', kwargs={'username': request.user.username})
        qr_code = generate_qr_code_for_url(portfolio_url, fill_color="#1E3A8A")

        return render(request, 'auth/qr_business_card.html', {
            'card_type': 'owner',
            'card_title': 'Verified Property Owner',
            'card_icon': 'home',
            'portfolio_url': portfolio_url,
            'qr_code': qr_code,
        })


class MoverQRCardView(LoginRequiredMixin, View):
    """QR business card for a verified mover, linking to their public portfolio"""

    def get(self, request):
        profile = request.user.profile
        if profile.role != 'mover' or not profile.is_verified_mover:
            messages.error(request, "You need to be a verified mover to get a Mover QR card.")
            return redirect('my_profile')

        from django.conf import settings
        from django.urls import reverse
        from users.utils import generate_qr_code_for_url

        portfolio_url = settings.SITE_URL.rstrip('/') + reverse('home:mover_detail', kwargs={'username': request.user.username})
        qr_code = generate_qr_code_for_url(portfolio_url, fill_color="#D97706")

        return render(request, 'auth/qr_business_card.html', {
            'card_type': 'mover',
            'card_title': 'Verified Mover',
            'card_icon': 'truck',
            'portfolio_url': portfolio_url,
            'qr_code': qr_code,
        })


class RegenerateQRView(LoginRequiredMixin, View):
    """View to regenerate QR code for the current user"""

    def get(self, request):
        profile = request.user.profile

        # Regenerate QR code
        success = profile.regenerate_qr_code()

        if success:
            messages.success(request, 'QR Code regenerated successfully!')
        else:
            messages.error(request, 'Failed to regenerate QR code. Please try again.')

        return redirect('my_profile')


class RequestOwnerVerificationView(LoginRequiredMixin, View):
    """Let a user (re)submit their profile for owner/mover verification"""

    def post(self, request):
        profile = request.user.profile
        profile.request_role_verification()
        role_label = 'property owner' if profile.role == 'owner' else 'mover'
        messages.info(
            request,
            f"Your request to become a verified {role_label} has been submitted. "
            "Our team will review it shortly."
        )
        return redirect('my_profile')


class OwnerVerificationQueueView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    """Admin-only queue of pending owner/mover verification requests"""
    model = Profile
    template_name = 'auth/owner_verification_queue.html'
    context_object_name = 'profiles'
    paginate_by = 20

    def test_func(self):
        return self.request.user.is_superuser

    def get_queryset(self):
        return Profile.objects.filter(
            role__in=['owner', 'mover'], verification_status='pending'
        ).select_related('user').order_by('verification_requested_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['pending_count'] = self.get_queryset().count()
        context['recently_reviewed'] = Profile.objects.filter(
            role__in=['owner', 'mover']
        ).exclude(verification_status='pending').exclude(
            verification_reviewed_at__isnull=True
        ).select_related('user').order_by('-verification_reviewed_at')[:10]
        return context


class ApproveOwnerVerificationView(LoginRequiredMixin, UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.is_superuser

    def post(self, request, pk):
        profile = get_object_or_404(Profile, pk=pk)
        profile.approve_role_verification(reviewer=request.user)
        role_label = 'property owner' if profile.role == 'owner' else 'mover'
        messages.success(request, f"{profile.get_full_name()} is now a verified {role_label}.")
        return redirect('owner_verification_queue')


class RejectOwnerVerificationView(LoginRequiredMixin, UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.is_superuser

    def post(self, request, pk):
        profile = get_object_or_404(Profile, pk=pk)
        notes = request.POST.get('notes', '')
        profile.reject_role_verification(reviewer=request.user, notes=notes)
        messages.warning(request, f"{profile.get_full_name()}'s verification request was rejected.")
        return redirect('owner_verification_queue')